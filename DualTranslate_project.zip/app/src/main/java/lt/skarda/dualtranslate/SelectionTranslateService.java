package lt.skarda.dualtranslate;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Deque;
import java.util.Locale;

public class SelectionTranslateService extends AccessibilityService {
    private static final String ELEVEN_READER = "io.elevenlabs.readerapp";
    private static final String PREFS = "dual_translate_prefs";
    private static final long DEBOUNCE_MS = 650;
    private static final int MAX_SELECTED_CHARS = 1500;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable pendingSelection;
    private Runnable hidePopup;
    private String candidate = null;
    private String lastTranslated = null;
    private long lastTranslatedAt = 0L;
    private long armedUntil = 0L;

    private WindowManager wm;
    private View popup;
    private TextView sourceView;
    private TextView ltView;
    private TextView ruView;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        saveDiagnostic("Service connected. Waiting for text selection in ElevenReader.");
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        if (!ELEVEN_READER.contentEquals(event.getPackageName())) return;

        int type = event.getEventType();
        if (type == AccessibilityEvent.TYPE_VIEW_LONG_CLICKED) {
            armedUntil = SystemClock.uptimeMillis() + 6000;
            saveDiagnostic(describeEvent(event, "LONG_CLICK"));
            handler.postDelayed(this::scanActiveWindowForSelection, 250);
            handler.postDelayed(this::scanActiveWindowForSelection, 650);
            return;
        }

        if (type == AccessibilityEvent.TYPE_VIEW_TEXT_SELECTION_CHANGED) {
            String selected = extractFromEvent(event);
            saveDiagnostic(describeEvent(event, selected == null ? "SELECTION(no text)" : "SELECTION: “" + trimForLog(selected) + "”"));
            if (selected != null) {
                armedUntil = SystemClock.uptimeMillis() + 6000;
                queueTranslation(selected);
            } else {
                handler.postDelayed(this::scanActiveWindowForSelection, 120);
            }
            return;
        }

        if (type == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED && SystemClock.uptimeMillis() < armedUntil) {
            handler.postDelayed(this::scanActiveWindowForSelection, 120);
        }
    }

    @Override
    public void onInterrupt() {
        removePopup();
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        removePopup();
        super.onDestroy();
    }

    private void queueTranslation(String raw) {
        String text = normalize(raw);
        if (text == null) return;
        candidate = text;
        if (pendingSelection != null) handler.removeCallbacks(pendingSelection);
        pendingSelection = () -> {
            String finalText = candidate;
            if (finalText == null) return;

            long now = SystemClock.uptimeMillis();
            if (finalText.equals(lastTranslated) && now - lastTranslatedAt < 5000) return;
            lastTranslated = finalText;
            lastTranslatedAt = now;
            translateAndShow(finalText);
        };
        handler.postDelayed(pendingSelection, DEBOUNCE_MS);
    }

    private void translateAndShow(String text) {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String key = prefs.getString("api_key", "").trim();
        if (key.isEmpty()) {
            showPopup(text, "Open Dual Translate and add your Google Cloud Translation API key.", "");
            return;
        }

        showPopup(text, "Translating…", "Translating…");
        GoogleTranslateClient.translateBoth(key, text, new GoogleTranslateClient.Callback() {
            @Override public void onResult(String lt, String ru) {
                handler.post(() -> showPopup(text, lt, ru));
            }

            @Override public void onError(String error) {
                handler.post(() -> showPopup(text, "Translation error", error));
            }
        });
    }

    private String extractFromEvent(AccessibilityEvent e) {
        AccessibilityNodeInfo source = e.getSource();
        String fromNode = extractFromNode(source);
        if (fromNode != null) return fromNode;

        int from = e.getFromIndex();
        int to = e.getToIndex();
        if (from >= 0 && to > from && e.getText() != null) {
            for (CharSequence cs : e.getText()) {
                if (cs == null) continue;
                String full = cs.toString();
                if (to <= full.length()) return full.substring(from, to);
            }
        }
        return null;
    }

    private String extractFromNode(AccessibilityNodeInfo node) {
        if (node == null) return null;
        CharSequence cs = node.getText();
        int start = node.getTextSelectionStart();
        int end = node.getTextSelectionEnd();
        if (cs != null && start >= 0 && end > start && end <= cs.length()) {
            return cs.subSequence(start, end).toString();
        }
        return null;
    }

    private void scanActiveWindowForSelection() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            saveDiagnostic("Scan: ElevenReader root window is not available.");
            return;
        }

        Deque<AccessibilityNodeInfo> q = new ArrayDeque<>();
        q.add(root);
        int visited = 0;
        while (!q.isEmpty() && visited < 1200) {
            AccessibilityNodeInfo n = q.removeFirst();
            visited++;
            String selected = extractFromNode(n);
            if (selected != null) {
                saveDiagnostic("Scan found selected range: “" + trimForLog(selected) + "”\nNode: " + safe(n.getClassName()));
                queueTranslation(selected);
                return;
            }
            for (int i = 0; i < n.getChildCount(); i++) {
                AccessibilityNodeInfo child = n.getChild(i);
                if (child != null) q.addLast(child);
            }
        }
        saveDiagnostic("Scan completed: " + visited + " nodes inspected; no Android text-selection range exposed yet.");
    }

    private String normalize(String raw) {
        if (raw == null) return null;
        String text = raw.replace('\u00A0', ' ').replaceAll("\\s+", " ").trim();
        if (text.isEmpty()) return null;
        if (text.length() > MAX_SELECTED_CHARS) text = text.substring(0, MAX_SELECTED_CHARS);
        return text;
    }

    private void showPopup(String source, String lt, String ru) {
        if (wm == null) wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (popup == null) createPopup();

        sourceView.setText(source);
        ltView.setText("LT  " + (lt == null ? "" : lt));
        ruView.setText(ru == null || ru.isEmpty() ? "" : "RU  " + ru);
        ruView.setVisibility(ru == null || ru.isEmpty() ? View.GONE : View.VISIBLE);

        if (popup.getWindowToken() == null) {
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
            lp.type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY;
            lp.format = PixelFormat.TRANSLUCENT;
            lp.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
            lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            lp.width = (int) (getResources().getDisplayMetrics().widthPixels * 0.92f);
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
            lp.y = dp(70);
            wm.addView(popup, lp);
        }

        popup.setVisibility(View.VISIBLE);
        if (hidePopup != null) handler.removeCallbacks(hidePopup);
        hidePopup = this::removePopup;
        handler.postDelayed(hidePopup, 12000);
    }

    private void createPopup() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(14), dp(18), dp(14));
        card.setBackgroundResource(lt.skarda.dualtranslate.R.drawable.popup_bg);
        card.setElevation(dp(10));
        card.setOnClickListener(v -> removePopup());

        sourceView = new TextView(this);
        sourceView.setTextSize(14);
        sourceView.setTextColor(Color.rgb(205, 205, 205));
        sourceView.setMaxLines(3);
        card.addView(sourceView);

        ltView = new TextView(this);
        ltView.setTextSize(20);
        ltView.setTextColor(Color.WHITE);
        ltView.setPadding(0, dp(10), 0, 0);
        card.addView(ltView);

        ruView = new TextView(this);
        ruView.setTextSize(20);
        ruView.setTextColor(Color.WHITE);
        ruView.setPadding(0, dp(8), 0, 0);
        card.addView(ruView);

        TextView hint = new TextView(this);
        hint.setText("tap card to close");
        hint.setTextSize(11);
        hint.setTextColor(Color.rgb(165, 165, 165));
        hint.setGravity(Gravity.END);
        hint.setPadding(0, dp(8), 0, 0);
        card.addView(hint);

        popup = card;
    }

    private void removePopup() {
        if (popup != null && popup.getWindowToken() != null && wm != null) {
            try { wm.removeView(popup); } catch (Exception ignored) {}
        }
    }

    private String describeEvent(AccessibilityEvent e, String note) {
        StringBuilder sb = new StringBuilder();
        sb.append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date()));
        sb.append("\n").append(note);
        sb.append("\nclass=").append(safe(e.getClassName()));
        sb.append(" from=").append(e.getFromIndex()).append(" to=").append(e.getToIndex());
        AccessibilityNodeInfo src = e.getSource();
        if (src != null) {
            sb.append("\nnodeClass=").append(safe(src.getClassName()));
            sb.append(" sel=").append(src.getTextSelectionStart()).append("..").append(src.getTextSelectionEnd());
            CharSequence t = src.getText();
            if (t != null) sb.append(" text=“").append(trimForLog(t.toString())).append("”");
        }
        return sb.toString();
    }

    private void saveDiagnostic(String s) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("diagnostics", s).apply();
    }

    private static String safe(CharSequence s) { return s == null ? "null" : s.toString(); }

    private static String trimForLog(String s) {
        String n = s.replaceAll("\\s+", " ").trim();
        return n.length() <= 180 ? n : n.substring(0, 180) + "…";
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}

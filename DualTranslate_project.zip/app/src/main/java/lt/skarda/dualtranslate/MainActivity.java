package lt.skarda.dualtranslate;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String PREFS = "dual_translate_prefs";
    private TextView serviceStatus;
    private TextView diagnostics;
    private EditText apiKey;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildUi());
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
    }

    private View buildUi() {
        int p = dp(20);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(p, p, p, p);
        scroll.addView(root);

        TextView title = text("Dual Translate", 28, true);
        root.addView(title);

        TextView sub = text("Automatic EN → Lithuanian + Russian translation for text selected in ElevenReader.", 16, false);
        sub.setPadding(0, dp(6), 0, dp(20));
        root.addView(sub);

        serviceStatus = text("Accessibility service: checking…", 17, true);
        root.addView(serviceStatus);

        Button accessibility = new Button(this);
        accessibility.setText("OPEN ACCESSIBILITY SETTINGS");
        accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(accessibility, matchWrap(dp(12)));

        TextView how = text("Enable “Dual Translate” once. The service is restricted to ElevenReader (io.elevenlabs.readerapp). After that, select an English word or phrase; the translation card should appear automatically after about 0.65 s.", 15, false);
        how.setPadding(0, dp(8), 0, dp(20));
        root.addView(how);

        TextView keyLabel = text("Google Cloud Translation API key", 17, true);
        root.addView(keyLabel);

        apiKey = new EditText(this);
        apiKey.setHint("Paste API key here");
        apiKey.setSingleLine(true);
        apiKey.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        apiKey.setText(getSharedPreferences(PREFS, MODE_PRIVATE).getString("api_key", ""));
        root.addView(apiKey, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        Button save = new Button(this);
        save.setText("SAVE API KEY");
        save.setOnClickListener(v -> {
            String key = apiKey.getText().toString().trim();
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("api_key", key).apply();
            Toast.makeText(this, key.isEmpty() ? "API key removed" : "API key saved", Toast.LENGTH_SHORT).show();
        });
        root.addView(save, matchWrap(dp(8)));

        TextView keyHelp = text("The key is stored only in this app's private storage. Cloud Translation must be enabled for the Google Cloud project. No clipboard permission is used.", 14, false);
        keyHelp.setPadding(0, dp(6), 0, dp(20));
        root.addView(keyHelp);

        Button test = new Button(this);
        test.setText("TEST GOOGLE TRANSLATION");
        test.setOnClickListener(v -> testTranslation());
        root.addView(test, matchWrap(dp(10)));

        TextView diagTitle = text("ElevenReader diagnostics", 17, true);
        diagTitle.setPadding(0, dp(18), 0, dp(6));
        root.addView(diagTitle);

        diagnostics = text("No selection event captured yet.", 13, false);
        diagnostics.setTextColor(Color.DKGRAY);
        diagnostics.setTextIsSelectable(true);
        root.addView(diagnostics);

        Button refresh = new Button(this);
        refresh.setText("REFRESH DIAGNOSTICS");
        refresh.setOnClickListener(v -> refreshStatus());
        root.addView(refresh, matchWrap(dp(8)));

        return scroll;
    }

    private void testTranslation() {
        String key = apiKey.getText().toString().trim();
        if (key.isEmpty()) {
            Toast.makeText(this, "Enter and save a Google Cloud Translation API key first.", Toast.LENGTH_LONG).show();
            return;
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("api_key", key).apply();
        Toast.makeText(this, "Testing: galvanized steel", Toast.LENGTH_SHORT).show();
        GoogleTranslateClient.translateBoth(key, "galvanized steel", new GoogleTranslateClient.Callback() {
            @Override public void onResult(String lt, String ru) {
                runOnUiThread(() -> new android.app.AlertDialog.Builder(MainActivity.this)
                        .setTitle("Google translation test")
                        .setMessage("LT: " + lt + "\n\nRU: " + ru)
                        .setPositiveButton("OK", null)
                        .show());
            }

            @Override public void onError(String error) {
                runOnUiThread(() -> new android.app.AlertDialog.Builder(MainActivity.this)
                        .setTitle("Translation error")
                        .setMessage(error)
                        .setPositiveButton("OK", null)
                        .show());
            }
        });
    }

    private void refreshStatus() {
        boolean enabled = isAccessibilityServiceEnabled(this, SelectionTranslateService.class);
        if (serviceStatus != null) {
            serviceStatus.setText(enabled ? "Accessibility service: ENABLED" : "Accessibility service: DISABLED");
            serviceStatus.setTextColor(enabled ? Color.rgb(0, 120, 60) : Color.rgb(180, 30, 30));
        }
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (diagnostics != null) diagnostics.setText(p.getString("diagnostics", "No ElevenReader selection event captured yet."));
    }

    private static boolean isAccessibilityServiceEnabled(Context context, Class<?> serviceClass) {
        ComponentName expected = new ComponentName(context, serviceClass);
        String enabled = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) return false;
        for (String entry : enabled.split(":")) {
            ComponentName cn = ComponentName.unflattenFromString(entry);
            if (expected.equals(cn)) return true;
        }
        return false;
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(sp);
        v.setTextColor(Color.rgb(30, 30, 30));
        if (bold) v.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        return v;
    }

    private LinearLayout.LayoutParams matchWrap(int topMargin) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = topMargin;
        return lp;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}

package lt.skarda.dualtranslate;

import android.text.Html;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public final class GoogleTranslateClient {
    public interface Callback {
        void onResult(String lt, String ru);
        void onError(String error);
    }

    private static final ExecutorService EXECUTOR = Executors.newFixedThreadPool(2);

    private GoogleTranslateClient() {}

    public static void translateBoth(String apiKey, String text, Callback callback) {
        final String[] results = new String[2];
        final String[] errors = new String[2];
        final AtomicInteger finished = new AtomicInteger(0);

        translateOne(apiKey, text, "lt", (result, error) -> {
            results[0] = result;
            errors[0] = error;
            completeIfDone(finished, results, errors, callback);
        });
        translateOne(apiKey, text, "ru", (result, error) -> {
            results[1] = result;
            errors[1] = error;
            completeIfDone(finished, results, errors, callback);
        });
    }

    private static synchronized void completeIfDone(AtomicInteger finished, String[] results, String[] errors, Callback callback) {
        if (finished.incrementAndGet() != 2) return;
        if (errors[0] != null || errors[1] != null) {
            callback.onError("LT: " + (errors[0] == null ? "OK" : errors[0]) + "\nRU: " + (errors[1] == null ? "OK" : errors[1]));
        } else {
            callback.onResult(results[0], results[1]);
        }
    }

    private interface OneCallback { void done(String result, String error); }

    private static void translateOne(String apiKey, String text, String target, OneCallback cb) {
        EXECUTOR.execute(() -> {
            HttpURLConnection conn = null;
            try {
                String endpoint = "https://translation.googleapis.com/language/translate/v2?key=" + URLEncoder.encode(apiKey, "UTF-8");
                conn = (HttpURLConnection) new URL(endpoint).openConnection();
                conn.setRequestMethod("POST");
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(15000);
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                conn.setRequestProperty("Accept", "application/json");

                JSONObject body = new JSONObject();
                body.put("q", text);
                body.put("source", "en");
                body.put("target", target);
                body.put("format", "text");

                byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
                try (OutputStream os = conn.getOutputStream()) { os.write(bytes); }

                int code = conn.getResponseCode();
                InputStream stream = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
                String response = readAll(stream);
                if (code < 200 || code >= 300) {
                    cb.done(null, "HTTP " + code + ": " + extractError(response));
                    return;
                }

                JSONObject json = new JSONObject(response);
                JSONArray translations = json.getJSONObject("data").getJSONArray("translations");
                String translated = translations.getJSONObject(0).getString("translatedText");
                translated = Html.fromHtml(translated, Html.FROM_HTML_MODE_LEGACY).toString();
                cb.done(translated, null);
            } catch (Exception e) {
                cb.done(null, e.getClass().getSimpleName() + ": " + (e.getMessage() == null ? "unknown error" : e.getMessage()));
            } finally {
                if (conn != null) conn.disconnect();
            }
        });
    }

    private static String extractError(String response) {
        try {
            JSONObject json = new JSONObject(response);
            return json.getJSONObject("error").optString("message", response);
        } catch (Exception ignored) {
            return response == null || response.isEmpty() ? "No response from Google" : response;
        }
    }

    private static String readAll(InputStream in) throws Exception {
        if (in == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
        }
        return sb.toString();
    }
}
